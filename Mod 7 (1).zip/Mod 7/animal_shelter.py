from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    def __init__(self, username, password):
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32083
        DB = 'AAC'
        COL = 'animals'

        self.client = MongoClient(f'mongodb://{username}:{password}@{HOST}:{PORT}/?authSource=admin')
        self.database = self.client[DB]
        self.collection = self.database[COL]


    def create(self, data):
        if data:
            result = self.collection.insert_one(data)
            return str(result.inserted_id)
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, criteria):
        if criteria:
            return list(self.collection.find(criteria))
        else:
            return list(self.collection.find())
